var JS_masque = {
"type": "FeatureCollection",
"name": "masque",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "Id": 0 }, "geometry": { "type": "Polygon", "coordinates": [ [ [ -56.113108708208195, 63.617576665193639 ], [ 59.638500678268542, 64.591788782259414 ], [ 25.635365219782468, 18.197856960881261 ], [ -21.021397134965301, 17.794208696156364 ], [ -56.113108708208195, 63.617576665193639 ] ] ] } }
]
}
